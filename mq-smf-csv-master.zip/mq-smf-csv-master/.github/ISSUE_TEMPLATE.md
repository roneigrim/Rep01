Please include the following information in your ticket.

- mq-smf-csvs version(s) that are affected by this issue.
- A data sample that demonstrates the issue
- Command used to format the data
- Actual and expected output (data files and screen)
