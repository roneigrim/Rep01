The paramaters of the JCL and REXX exec are explained in the IBM Redbooks publication, chapter 7, 'Implementing REXX support in SDSF', SG24-7419. Please, review this chapter before executing the sample.

You will need to load both the REXX exec and the JCL to libraries on
your z/OS system. Change the SYSEXEC library in the JCL to where you stored the REXX exec.

To run the sample successfully you will need to be able to access an SMTP server and configure the mail parameters as needed.