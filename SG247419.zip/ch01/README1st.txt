This directory contains 3 other text files:
@SYSCMD.txt
JCL1.txt
JCL2.txt

@SYSCMD.txt contains the REXX exec.
JCL1.txt and JCL2.txt contain the JCL to run scenarios 1 through 10 as described in the IBM Redbooks publication,Chapter 1 of the 'Implementing REXX Support in SDSF', SG24-7419.

See the 'Introduction and Overview' chapter of the same publication for other ways to run this REXX exec.
