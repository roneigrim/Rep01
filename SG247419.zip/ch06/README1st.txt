1. Upload the REXX exec to your Host system
2. Execute it either under TSO or under Unix System Services

See the IBM Redbooks publication, Chapter 6, 'Implementing REXX support in SDSF', SG24-7419.