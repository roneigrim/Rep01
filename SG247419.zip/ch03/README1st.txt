Instructions for installing and using LISTPROC, the SYSOUT List Processor

For details on what this EXEC does and how it does it, see the IBM Redbooks publication, chapter 3,Implementing REXX Support in SDSF, SG24-7419.

To install, simply copy the LISTPROC.REX and RESUBMIT.REX files to a CLIST dataset which is in the SYSPROC/SYSEXEC concatenation.