Details for implementation of each of the examples given in Chapters 9 and 10, Implementing REXX support in SDSF, SG24-7419 can be found in each chapter. 

1. Make sure you have Java 6 installed (see the book for details)
2) Make sure you have downloaded JFree Chart (see the book for details)
3) Run run.bat to run 