

 /*
 * Host.java
 *
 * Created on 29 marzo 2007, 1.50
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

 import java.net.*;
 import java.net.Socket;
 import java.io.*;
 import java.util.*;

 
public class Host {
    Socket s = null;
    DataInputStream input = null;
    DataOutputStream s_output = null;
    PrintStream output = null;
   
    //--------------------------------------------------------------------------
    public void cmd(String cmd)  
    {
      String  s_cmd;
      int     a, l;
      
      l = cmd.length();
      a = 10 - l;
      s_cmd = cmd;
      for(;;)
      {
        s_cmd = s_cmd + " ";
        --a;
        if (a == 0) break;
      }
                             
      try {
        s_output.writeBytes(s_cmd);
        s_output.flush();
      } catch (IOException e) {
         System.out.println("Host. Erorr writing data to the socket.");   
         System.out.println("Host. e: " + e.getMessage());
         System.exit(-1);
      }
    }
    
    //---------------------------------------------------------------------------
    public String get_data_from_host()   {
    String msg = "";
    String words[] = new String [200000];
    int   count, idx, i, a, campione;
    float f, cpu_total;
    byte   b;
    
  
    // send comand to host
    //cmd("get_data"); 
    msg = "";
    count = 0; 
    idx = 0;
      
    // reading data from the socket   
    for(;;)
    {    
      try
      {
        msg = "";
        for(a=0; a<10; a++)                  // get the length first
        {
          b = input.readByte();  
          if (b == ' ') b = '0';
          msg = msg + (char) b;
        }
        i = Integer.parseInt(msg);           // i= length of the data coming in
       
        msg = "";
        for(a=0; a<i; a++)                   // and then the real payload
        {
          b = input.readByte();  
          msg = msg + (char) b;  
        } 
        
        break;
        
      } catch (IOException e) {
         System.out.println("Host. Erorr reading data from the socket.");   
         System.out.println("Host. e: " + e.getMessage());
         System.exit(-1);
      }  
    }
     
   return(msg);
 }
    
     
    //--------------------------------------------------------------------------
    public void connect(String addr, String port)
    {
      int i;
      
      i = Integer.parseInt(port);
      
      try
      {
        s = new Socket(addr, i);
        input = new DataInputStream(s.getInputStream() );
        output = new PrintStream(s.getOutputStream());
        s_output = new DataOutputStream(s.getOutputStream() );
      } catch (IOException e) {
       System.out.println("Host. Erorr trying to connect the host system.");   
       System.out.println("Host. e: " + e.getMessage());
       System.exit(-1);
      } 
    }
  
    //--------------------------------------------------------------------------
    public void close()
    {
      cmd("end_end");
      try
      {
        s.close();
      } catch (IOException e) {
         System.out.println("Host. Erorr during socket close()");   
         System.out.println("Host. e: " + e.getMessage());  
      } 
    }
    
    
    //--------------------------------------------------------------------------
    public Host() {
    }
    
}
