/*
 * Grafico_1.java
 *
 * Created on 29 marzo 2007, 2.42
 */

 import java.io.*;
 import java.util.*;
 
 import java.awt.*;
 import java.awt.image.BufferedImage;
 import java.text.SimpleDateFormat;
 import javax.swing.DefaultListModel;
 import javax.swing.ImageIcon;
   
 import org.jfree.data.xy.*;
 import org.jfree.data.*;

 import org.jfree.chart.*;
 import org.jfree.data.general.DefaultPieDataset;
 import org.jfree.chart.axis.DateAxis;
 import org.jfree.chart.plot.*;
 import org.jfree.chart.axis.*;
 import org.jfree.data.category.*;
 import org.jfree.chart.renderer.category.*;
 import org.jfree.chart.renderer.xy.*;
 import org.jfree.chart.title.*;
 import org.jfree.chart.block.*;
 import org.jfree.ui.*;
   
/**
 *
 * @author  user1
 */
public class Grafico_1 extends javax.swing.JFrame {
    
    float[] tab_cpu = new float[20];
    int    tab_cpu_p;
    String job_selected = "";
    String sysname_selected = "";
    
    float[] tab_cpu_user = new float[20];
    int  tab_cpu_user_p;
    
    Vector list_data = new Vector();
    Vector list_data1 = new Vector();
    
    /** Creates new form Grafico_1 */
    public Grafico_1() {
        initComponents();
        tab_cpu_p = 0;
        tab_cpu_user_p = 0;
        setLocationRelativeTo(null);
    }
    
    //---------------------------------
    public int get_delay_value()
    {
      int   i;
      
      i = jSlider1.getValue();
      return(i);
    }
    
    //---------------------------------
    public String get_sysname_selected()
    {
      return(sysname_selected);
    }
    
    //----------------------------------
    public void set_sysnames(String s)
    {
      String words[] = new String [5000];
      String sysname;
      int    idx, count;
      
      StringTokenizer st = new StringTokenizer(s);
      count = st.countTokens();
      
      list_data1.clear();
      idx = 0;
      
      while (st.hasMoreTokens() ) 
      {                  
        words[idx] = st.nextToken(); 
        idx++; 
      }
      
      for(idx=0; idx<count; ++idx)
      {
        sysname = words[idx+0];                         
        list_data1.addElement(sysname);              // aggiungo il jobname al listbox
      } 
      
      jList2.setListData(list_data1);                // aggiorno il listbox
    }
    
    //-------------------------------------------
    public String draw(String msg, String job_sel)
    {
      String words[] = new String [1000];
      int   count, idx, i, a, campione;
      float f, f_p, cpu_total;
      byte   b;
      String job_name = "";
      String save_jobname = "";
      String save_io = "";
      String save_cpu = "";        
      String titolo = "CPU utilization for asid: ";
      String io_sort[] = new String[1000];
      int    s_a, s_b;
      
      
      // extracting the jobname and cpu
      
     idx = 0;
    
     StringTokenizer st = new StringTokenizer(msg);
     count = st.countTokens();
    
     while (st.hasMoreTokens() ) 
     { words[idx] = st.nextToken(); 
       idx++;
     }
   
     // ------------ Pie chart ------------------------------- 
    
     DefaultPieDataset pieDataset = new DefaultPieDataset();
    
     for (idx=0; idx<28; idx=idx+3)
     {  
       f = Float.parseFloat(words[idx+2]);
       pieDataset.setValue(words[idx], f);
     }
     JFreeChart chart = ChartFactory.createPieChart
     ("CPU % . Top 10 consumers", pieDataset, true, true, true);
     
     BufferedImage image = chart.createBufferedImage(550,300);
     jLabel1.setIcon(new ImageIcon(image));
    
     // -------------- cpu chart --------------------------------
   
     XYSeries series = new XYSeries("Average CPU");
     XYSeries series_1 = new XYSeries("User CPU");
     
     list_data.clear();
     cpu_total = 0;
     for(idx=0; idx<count-1; idx=idx+3)
     {
       job_name = words[idx+0];                         
       list_data.addElement(job_name);              // aggiungo il jobname al listbox
       f = Float.parseFloat(words[idx+2]);
       cpu_total = cpu_total + f;
       
       if (job_sel.equalsIgnoreCase(job_name))         // se � il job selezionato aggiorno la tabella
       {
         f = Float.parseFloat(words[idx+2]);  
         tab_cpu_user[tab_cpu_user_p] = f;
         ++tab_cpu_user_p;
         if (tab_cpu_user_p == 20) tab_cpu_user_p = 0;              
       }    
       
     }    
     
     jList1.setListData(list_data);                // aggiorno il listbox
    
     tab_cpu[tab_cpu_p] = cpu_total;
     ++tab_cpu_p;
     if (tab_cpu_p == 20) tab_cpu_p = 0;
     
     //  preparo i  grafici
     
     i = tab_cpu_p;
     campione = 0;
    
     for(;;)                                 // grafico cpu totale
     {   
       series.add(campione, tab_cpu[i]);
       ++campione;
       ++i;
       if (i == tab_cpu_p) break;
       if (i == 20) i = 0;
       if ((i ==0) & (tab_cpu_p == 0)) break;
     }
     
     XYDataset xyDataset = new XYSeriesCollection(series);    
     JFreeChart chart_1 = ChartFactory.createXYAreaChart
         ("CPU total % of utilization", "Sample", "CPU Usage",
          xyDataset, PlotOrientation.VERTICAL, true, 
           true, false);
    
    XYPlot plot = (XYPlot) chart_1.getPlot();
    XYAreaRenderer renderer = (XYAreaRenderer) plot.getRenderer();
    renderer.setSeriesPaint(0, Color.green);
     
     BufferedImage image_1 = chart_1.createBufferedImage(500,300);
     jLabel2.setIcon(new ImageIcon(image_1));

     
     i = tab_cpu_user_p;
     campione = 0;
    
     for(;;)                                 // grafico cpu user
     {   
       series_1.add(campione, tab_cpu_user[i]);
       ++campione;
       ++i;
       if (i == tab_cpu_user_p) break;
       if (i == 20) i = 0;
       if ((i ==0) & (tab_cpu_user_p == 0)) break;
     }
     
     titolo = titolo + job_sel;
     XYDataset xyDataset_1 = new XYSeriesCollection(series_1);  
     JFreeChart chart_2 = ChartFactory.createXYAreaChart
         (titolo, "Sample", "CPU Usage",
          xyDataset_1, PlotOrientation.VERTICAL, true, 
           true, false);
     
     XYPlot plot_2 = (XYPlot) chart_2.getPlot();
     XYAreaRenderer renderer_2 = (XYAreaRenderer) plot_2.getRenderer();
     renderer_2.setSeriesPaint(0, Color.red);
    
     BufferedImage image_2 = chart_2.createBufferedImage(500,300);
     jLabel3.setIcon(new ImageIcon(image_2));
   
     // ------------------------- bar chart -----------------------------
     
     count = count / 3;
     
     for(s_a=0; s_a<count; s_a++)
     {
       idx = 0;  
       for(s_b=0; s_b<count-1; s_b++)
       {
         f = Float.parseFloat(words[idx+1]);
         f_p = Float.parseFloat(words[idx+4]);
         if (f_p > f) 
         {
           save_jobname = words[idx+0];
           save_io = words[idx+1];
           save_cpu = words[idx+2];
           words[idx+0] = words[idx+3];
           words[idx+1] = words[idx+4];
           words[idx+2] = words[idx+5];
           words[idx+3] = save_jobname;
           words[idx+4] = save_io;
           words[idx+5] = save_cpu;
         }    
         idx = idx + 3;
       }     
     }
     
     DefaultCategoryDataset dataset_io = new DefaultCategoryDataset();
     idx = 0;
     for(s_a=0; s_a<10; s_a++)
     { 
       f = Float.parseFloat(words[idx+1]);
       i = (int) f;
       dataset_io.setValue((double)i, words[idx+0],"");
       idx = idx + 3;  
     }    
     
     JFreeChart chart_io = ChartFactory.createBarChart3D
      ("EXCP / second. TOP 10 users","ASID", "sio per second", 
      dataset_io, PlotOrientation.VERTICAL, true,true, false);
     // chart_io.setBackgroundPaint(Color.yellow);
      //chart_io.getTitle().setPaint(Color.blue); 
      CategoryPlot p = chart_io.getCategoryPlot(); 
      //p.setRangeGridlinePaint(Color.red); 
      
      BufferedImage image_4 = chart_io.createBufferedImage(500,300);
      jLabel9.setIcon(new ImageIcon(image_4));
     
     
     return(job_selected);
}    
    
   
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSlider1 = new javax.swing.JSlider();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Example_1 SDSF REXX");
        setResizable(false);
        jLabel1.setText(" ");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel2.setText(" ");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel3.setText(" ");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jList1.setFont(new java.awt.Font("Courier New", 0, 14));
        jScrollPane1.setViewportView(jList1);

        jButton1.setText("Select ASID");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Courier New", 1, 15));
        jLabel5.setText(" ");

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 1, 18));
        jLabel6.setForeground(new java.awt.Color(0, 102, 255));
        jLabel6.setText("ASID:");

        jLabel4.setText("Refresh Rate");

        jSlider1.setMaximum(20);
        jSlider1.setMinimum(1);
        jSlider1.setValue(10);

        jList2.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jList2);

        jButton2.setText("Select System");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Comic Sans MS", 1, 18));
        jLabel7.setForeground(new java.awt.Color(0, 102, 255));
        jLabel7.setText("System:");

        jLabel8.setFont(new java.awt.Font("Courier New", 1, 15));
        jLabel8.setText(" ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                .addGap(17, 17, 17))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(23, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE))
                        .addGap(17, 17, 17))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSlider1, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel4)
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel9.setText(" ");
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 303, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 303, Short.MAX_VALUE))))
                .addContainerGap())
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      int i;
       
      try {
        i = jList2.getSelectedIndex();
        sysname_selected = (String) list_data1.get(i);
      } catch (ArrayIndexOutOfBoundsException ex) {
      }
      
      jLabel8.setText(sysname_selected);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      int i;
      
      try {
        i = jList1.getSelectedIndex();
        job_selected = (String) list_data.get(i);
      } catch (ArrayIndexOutOfBoundsException ex) {
      }
      
      jLabel5.setText(job_selected);
      
    }//GEN-LAST:event_jButton1ActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList1;
    private javax.swing.JList jList2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSlider jSlider1;
    // End of variables declaration//GEN-END:variables
    
}
