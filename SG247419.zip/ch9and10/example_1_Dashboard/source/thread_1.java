/*
 * thread_1.java
 *
 * Created on 29 marzo 2007, 2.04
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

 import java.net.*;
 import java.net.Socket;
 import java.io.*;
 import java.util.*;
 import javax.swing.JDialog;
 import javax.swing.JOptionPane;
  
/**
 *
 * @author user1
 */
public class thread_1 extends Thread  {
    
  String st = "";
  Host host;
  String job_selected = "";
  String host_addr;
  String host_port;
 
  
  public void close()
  {
    host.close();
  }
   
  //--------------------------- 
  public void get_server_info()
  {
    try {
          BufferedReader in = new BufferedReader(new FileReader("example1.txt"));
          String str;
          host_addr = in.readLine();        
          host_port = in.readLine();
          in.close();
    } catch(IOException e) {
        System.out.println("Thread_1: Error reading -> example1.txt");  
        System.exit(-1);
    }  
  }
  
  //--------------- 
  public void run()
  {
    int   delay_value, i;
    host = new Host();
    Grafico_1 graf_1 = new Grafico_1();
    String job_selected = "";
    String sysname_selected = "";
    String s_w;
    
    JOptionPane.showMessageDialog(null,
            "\n Connecting to the Server Program. " +
            "\n This may take a few seconds. Please Wait..." +
            "\n\n Press OK to continue\n\n");
    
    get_server_info();
    host.connect(host_addr, host_port);
    
    host.cmd("sysplex");                       // obtain the name of the system in the plex
    st = host.get_data_from_host();
    graf_1.set_sysnames(st);
    
    for(;;)
    {    
      sysname_selected = graf_1.get_sysname_selected();  
      s_w = "S";
      s_w = s_w + sysname_selected;           // get name of the system selected in the listbox
      boolean b = s_w.equals("S");
      if (! b)
      {    
        host.cmd(s_w);                          // issue a sysname command
      }
      
      host.cmd("D");
      st = host.get_data_from_host();
      job_selected = graf_1.draw(st, job_selected);
      graf_1.setVisible(true);
      delay_value = graf_1.get_delay_value();
      delay_value = delay_value * 500;
      try {
        Thread.sleep(delay_value);
      } catch (InterruptedException e) {
        System.out.println("Thread: Error in thread.");
        System.out.println("e:" + e.getMessage());  
      }
    } 
      
  }

}
