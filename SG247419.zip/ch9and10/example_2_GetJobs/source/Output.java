import java.util.Vector;
 
public class Output extends javax.swing.JFrame {
   
     //------------------------- 
     public void draw(String msg)
     {
       int  a, b, l, fine, inizio;
       String  s_s;
       Vector list_data = new Vector();
       
       list_data.removeAllElements();
      
       b = 1;
       l = msg.length();
       
       for(a=1; a<l; a++)
       {      
         inizio = a;
         fine = msg.indexOf("E_O_R", inizio);
         s_s = msg.substring(inizio, fine); 
         list_data.addElement(s_s);
         a = fine + 5;
         ++b;
       }

       jList1.setListData(list_data); 
       
     }
     
    /** Creates new form Output */
    public Output() {
        initComponents();
        setLocationRelativeTo(null);
    }
    
  
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();

        setTitle("SDSF REXX test program");
        jList1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jList1.setFont(new java.awt.Font("Courier New", 1, 15));
        jScrollPane1.setViewportView(jList1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 956, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
                .addContainerGap())
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
    
}
