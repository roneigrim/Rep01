import java.awt.Component;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class CustomTableCellRenderer extends DefaultTableCellRenderer 
{
    String s;

    public Component getTableCellRendererComponent
       (JTable table, Object value, boolean isSelected,
       boolean hasFocus, int row, int column) 
    {
        Component cell = super.getTableCellRendererComponent
           (table, value, isSelected, hasFocus, row, column);
        
        cell.setBackground(Color.WHITE);
        
        if (isSelected)
        {
           cell.setBackground(Color.yellow);    
        }
        
        if (column == 6)
        {
          cell.setBackground(Color.CYAN);         
          s =  table.getModel().getValueAt(row, 6).toString();
          if (s.equalsIgnoreCase("0000_"))  
          {
             cell.setBackground( Color.GREEN);   
          }
          
          if (s.equalsIgnoreCase("0004_"))  
          {
             cell.setBackground( Color.YELLOW);   
          }
          
          if (s.equals("0008_"))
          {
             cell.setBackground(Color.RED);
          }
          
        }        
        
        cell.setForeground(Color.BLACK);
        return(cell);
    }
}