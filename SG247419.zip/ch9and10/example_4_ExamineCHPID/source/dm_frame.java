import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class dm_frame extends javax.swing.JFrame {
    
    Setup setup = new Setup();
    Host host = new Host();
    String host_addr;
    String host_port;
    String tab_chp_status[][] = new String[17][17];
    DefaultTableModel model = new DefaultTableModel();
    TableCellRenderer renderer = new CustomTableCellRenderer();
    SpecificChpid spec_chpid = new SpecificChpid();
    
    
    String tab_chp[] = {"UNDEF", "BYTE", "CNC_P", "CNC_?", "CNC_S", "CVC", "NTV",    
                        "CTC_P", "CTC_S", "CTC_?", "CFS", "CFR", "UNDEF", "UNDEF",   
                        "CBY", "OSE", "OSD", "OSA", "ISD", "OSC", "OSN", "CBS",         
                        "CBR", "ICS", "ICR", "FC", "FC_S", "FCV", "FC_?", "DSD",         
                        "EIO", "UNDEF", "CBP", "CFP", "ICP", "IQD", "FCP", "CIB", "NA"};
     
    String tab_chp_desc[] = { "UNKNOWN",                                 
                           "PARALLEL BLOCK MULTIPLEX",                
                           "PARALLEL BYTE MULTIPLEX",                   
                           "ESCON POINT TO POINT",                    
                           "ESCON SWITCHED OR POINT TO POINT",         
                           "ESCON SWITCHED POINT TO POINT",           
                           "ESCON PATH TO A BLOCK CONVERTER",         
                           "NATIVE INTERFACE",                         
                           "CTC POINT TO POINT",                   
                           "CTC SWITCHED POINT TO POINT",         
                           "CTC SWITCHED OR POINT TO POINT",       
                           "COUPLING FACILITY SENDER",                
                           "COUPLING FACILITY RECEIVER",               
                           "UNKNOWN",                              
                           "UNKNOWN",                              
                           "ESCON PATH TO A BYTE CONVERTER",          
                           "OSA EXPRESS",                          
                           "OSA DIRECT EXPRESS",                  
                           "OPEN SYSTEMS ADAPTER",                  
                           "INTERNAL SYSTEM DEVICE",                  
                           "OSA CONSOLE",                            
                           "OSA NCP",                                
                           "CLUSTER BUS SENDER",                    
                           "CLUSTER BUS RECEIVER",                  
                           "INTERNAL COUPLING SENDER",               
                           "INTERNAL COUPLING RECEIVER",             
                           "FICON POINT TO POINT",                    
                           "FICON SWITCHED",                         
                           "FICON TO ESCON BRIDGE",                   
                           "FICON INCOMPLETE",                      
                           "DIRECT SYSTEM DEVICE",                    
                           "EMULATED I/O",                            
                           "RESERVED",                              
                           "INTEGRATED CLUSTER BUS PEER",             
                           "COUPLING FACILITY PEER",             
                           "INTERNAL COUPLING PEER",             
                           "INTERNAL QUEUED DIRECT COMM",        
                           "FCP CHANNEL",                         
                           "COUPLING OVER INFINIBAND"};   
    
    //---------------------------------------------
    private String get_chp_description(String s)
    {
       String s_w;
       int  a;
       
       for(a=0; a<39; a++)
       {
         if (tab_chp[a].equalsIgnoreCase(s) )
         {
            return(tab_chp_desc[a+1]);  
         }    
       }    
       
       return("not found");
    }    
   
    
    //----------------------------------
    private String get_chp_type(String s)
    {
      int i;
      String  s_t;
      
      i = Integer.parseInt(s, 16);
      s_t = tab_chp[i];
      return(s_t);
        
    }
    
    //---------------------------------
    private void setup_table(String s)
    {
      int  a, b;
      Vector v_data = new Vector(16);
      String tab_s[] = new String[17];
      String s_t, tipo;
       
      a = model.getRowCount();           // clear the table
      if (a > 0)
      {
        a = a - 1;
        for(;;)
        {
          if (a < 0) break;
          model.removeRow(a); 
          --a;
        }    
      }
      
      StringTokenizer st = new StringTokenizer(s);
      for (a=0; a<17; a++)
      {
        for(b=0; b<17; b++) 
        {    
          s_t = st.nextToken(); 
          tab_chp_status[a][b] = s_t;
        }
      }    
      
      v_data.clear();
      for (a=0; a<17; a++)
      {
        for(b=0; b<17; b++) 
        {    
          s_t = st.nextToken(); 
          if ((a>0) & (b>0))
          {
            tipo = get_chp_type(s_t);
            tipo = tab_chp_status[a][b] + tipo;
          } else {
            tipo = s_t;  
          }  
          tab_s[b] = tipo;
        }
        model.addRow(tab_s);
      } 
      
    }
    
    //--------------------------- 
    public void get_server_info()
    {
      try {
        BufferedReader in = new BufferedReader(new FileReader("example4.txt"));
        String str;
        host_addr = in.readLine();        
        host_port = in.readLine();
        in.close();
      } catch(IOException e) {
        System.out.println("get_server_info()1: Error reading -> example4.txt");  
        System.exit(-1);
      }  
    }
    
    /** Creates new form dm_frame */
    public dm_frame() {
      initComponents();
      setLocationRelativeTo(null);
      jTable1.setDefaultRenderer(Object.class, renderer);
      model = (DefaultTableModel) jTable1.getModel();
      jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setTitle("SDSF REXX Example_4");
        setResizable(false);
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                " ", " ", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTable1MouseEntered(evt);
            }
        });

        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1092, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.setText("Get Data");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Get CHP Data");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                .addGap(817, 817, 817))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 18));
        jLabel1.setText(" CHPID type: ");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Courier New", 1, 18));
        jLabel2.setForeground(new java.awt.Color(0, 51, 204));
        jLabel2.setText(" ");

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 1, 18));
        jLabel3.setText(" Status: ");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Courier New", 1, 18));
        jLabel4.setForeground(new java.awt.Color(0, 51, 204));
        jLabel4.setText(" ");

        jLabel5.setFont(new java.awt.Font("Comic Sans MS", 1, 18));
        jLabel5.setText(" CHPID # :  ");
        jLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel6.setFont(new java.awt.Font("Courier New", 1, 18));
        jLabel6.setText("00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(21, 21, 21)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel3)
                .addGap(16, 16, 16)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
      int  riga, colonna;
      String  s;
      char    stato;
      
      riga = jTable1.getSelectedRow();
      colonna = jTable1.getSelectedColumn();
      s  = (String) model.getValueAt(riga, colonna);
      stato = s.charAt(0);
      s = s.substring(1);
      s = get_chp_description(s);
      jLabel2.setText(s);
      
      if(stato == '+') jLabel4.setText("ONLINE");
      if(stato == '@') jLabel4.setText("PATH NOT VALIDATED");
      if(stato == '-') jLabel4.setText("OFFLINE");
      if(stato == '.') jLabel4.setText("DOES NOT EXIST");
      if(stato == '*') jLabel4.setText("MANAGED AND ONLINE");
      if(stato == '#') jLabel4.setText("MANAGED AND FLLINE");
      
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseEntered
// TODO add your handling code here:
    }//GEN-LAST:event_jTable1MouseEntered

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      int  riga, colonna, l, a, b;
      int  inizio, fine;
      String  s, s_r, s_c;
      
      riga = jTable1.getSelectedRow();
      colonna = jTable1.getSelectedColumn();
      s_r = (String) model.getValueAt(riga, 0);
      s_c = (String) model.getValueAt(0, colonna);
      s = s_r + s_c;
      jLabel6.setText(s);
      
      get_server_info();
      host.connect(host_addr, host_port);
      s = "H" + s;
      
      host.cmd(s);              
      s = host.get_data_from_host();
      host.close();
     
      spec_chpid.setVisible(true);
      spec_chpid.disegna(s);
      
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked

    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       String  s;
       
       get_server_info();
       host.connect(host_addr, host_port);
       s = "dm_chp";
       host.cmd(s);              
       s = host.get_data_from_host();
       if(!s.equalsIgnoreCase("NO_DATA")) setup_table(s);
       host.close();
    }//GEN-LAST:event_jButton1ActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
    
}
