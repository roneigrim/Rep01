import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
/*
 * SpecificChpid.java
 *
 * Created on 3 maggio 2007, 15.06
 */

/**
 *
 * @author  user1
 */
public class SpecificChpid extends javax.swing.JFrame {
    
    Host host = new Host();
    DevFrame dev_frame = new DevFrame();
    String tab_chp_status[][] = new String[17][100];
    int tab_chp_status_p;
    DefaultTableModel model = new DefaultTableModel();
    TableCellRenderer renderer = new CustomTableCellRenderer_1();
    String host_addr;
    String host_port;
     
    /** Creates new form SpecificChpid */
    public SpecificChpid() {
      initComponents();
      setLocationRelativeTo(null);
      jTable1.setDefaultRenderer(Object.class, renderer);
      model = (DefaultTableModel) jTable1.getModel();
      jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    
    //--------------------------- 
    public void get_server_info()
    {
      try {
        BufferedReader in = new BufferedReader(new FileReader("example4.txt"));
        String str;
        host_addr = in.readLine();        
        host_port = in.readLine();
        in.close();
      } catch(IOException e) {
        System.out.println("get_server_info()1: Error reading -> example4.txt");  
        System.exit(-1);
      }  
    }
   
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setTitle("SDSF REXX Example_4");
        setResizable(false);
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jList1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jList1.setFont(new java.awt.Font("Courier New", 1, 18));
        jScrollPane1.setViewportView(jList1);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable1.setFont(new java.awt.Font("Tahoma", 1, 13));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });

        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 732, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 732, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.setText("Get Device Data");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap(621, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      int  riga, colonna, l, a, b;
      int  inizio, fine;
      String  s, s_r, s_c;
      
      riga = jTable1.getSelectedRow();
      colonna = jTable1.getSelectedColumn();
      s_r = (String) model.getValueAt(riga, 0);
      s_c = (String) model.getValueAt(0, colonna);
      s = s_r + s_c;
      
      get_server_info();
      host.connect(host_addr, host_port);
      s = "J" + s;    
      host.cmd(s);              
      s = host.get_data_from_host();
      host.close();
      
      dev_frame.update_list(s);
      dev_frame.setVisible(true);
     
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
    
    }//GEN-LAST:event_jTable1MouseClicked
    
    //----------------------------------
    private String togli_blanks(String s)
    {
      int   l, a;
      char  c;
      
      l = s.length();
      for (a=0; a<l; a++)
      {
        c = s.charAt(a);
        if (c != ' ') 
        {
          s = s.substring(a);
          return(s);
        }    
      }    
      
      return(s);
    }
    
    //----------------------------------------
    private void update_table_status(String s)
    {
      int     a;
      String  s_t; 
      
      StringTokenizer st = new StringTokenizer(s);
      for (a=0; a<17; a++)
      {
        s_t = st.nextToken(); 
        tab_chp_status[a][tab_chp_status_p] = s_t;
      }    
      
      ++tab_chp_status_p;     
    }
    
    //---------------------------
    public void disegna(String s)
    {
      int    a, b, l, rc,inizio, fine, dev_sw, trovato;
      char   c;
      String s_s, s_w;
      String tab_s[] = new String[17];
      String tt[] = {"*","0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
      
      Vector list_data = new Vector(); 
      list_data.removeAllElements();
      

      dev_sw = 0;
      tab_chp_status_p = 0;
      b = 1;
      l = s.length();
  
      for(a=1; a<l; a++)
      {      
        inizio = a;
        fine = s.indexOf("E_O_R", inizio);
        s_s = s.substring(inizio, fine); 
        s_s = togli_blanks(s_s);

        trovato = 0; 
        rc = s_s.indexOf("CHPID ");
        if (rc >= 0) trovato = 1;
        rc = s_s.indexOf("SWITCH ");
        if (rc >= 0) trovato = 1;
        rc = s_s.indexOf("PHYSICAL ");
        if (rc >= 0) trovato = 1;          
        if (trovato == 1) list_data.addElement(s_s);    
        
        if (dev_sw == 1)
        {
          c = s_s.charAt(0);
          if ((c >= '0') & (c <= 'F')) 
          {
            update_table_status(s_s); 
          } else {
            dev_sw = 0;  
          }  
        }    
        s_w = s_s.substring(0, 2);
        if (s_w.equalsIgnoreCase("0 ") )
        {    
          dev_sw = 1;
        }    
        a = fine + 5;
        ++b;
      }
      
      jList1.setListData(list_data); 
      
      //---- clear the table --------------------    
      a = model.getRowCount();            
      if (a > 0)
      {
        a = a - 1;
        for(;;)
        {
          if (a < 0) break;
          model.removeRow(a); 
          --a;
        }    
      }
            
      model.addRow(tt);
      for(a=0; a<tab_chp_status_p; a++)
      {
        for(b=0; b<17; b++)
        {
          tab_s[b] = tab_chp_status[b][a];  
        }    
        model.addRow(tab_s);
      }    
      
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JList jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
    
}
