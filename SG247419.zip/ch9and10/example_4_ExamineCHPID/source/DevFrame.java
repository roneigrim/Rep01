import java.util.Vector;
/*
 * DevFrame.java
 *
 * Created on 3 maggio 2007, 17.55
 */

/**
 *
 * @author  user1
 */
public class DevFrame extends javax.swing.JFrame {
    
    /** Creates new form DevFrame */
    public DevFrame() {
        initComponents();
    }
    
    //----------------------------------
    private String togli_blanks(String s)
    {
      int   l, a;
      char  c;
      
      l = s.length();
      for (a=0; a<l; a++)
      {
        c = s.charAt(a);
        if (c != ' ') 
        {
          s = s.substring(a);
          return(s);
        }    
      }    
      
      return(s);
    }
  
    //-------------------------------
    public void update_list(String s)
    {
      int     a, b, inizio, fine, l;
      String  s_s;
      
      Vector list_data = new Vector(); 
      list_data.removeAllElements();
      
      l = s.length();
      b = 1;
      
      for(a=1; a<l; a++)
      {      
        inizio = a;
        fine = s.indexOf("E_O_R", inizio);
        s_s = s.substring(inizio, fine); 
        s_s = togli_blanks(s_s);
        list_data.addElement(s_s);
        a = fine + 5;
        ++b;
      }  
      
      jList1.setListData(list_data);
 
    }
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();

        setTitle("SDSF REXX Example_4");
        setResizable(false);
        jList1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jList1.setFont(new java.awt.Font("Courier New", 1, 18));
        jScrollPane1.setViewportView(jList1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 806, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
                .addContainerGap())
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
    
}
