import java.awt.Component;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class CustomTableCellRenderer_1 extends DefaultTableCellRenderer 
{
    String s, s_1;
    int    l;
    char   c;
   
    Color color_selected = new Color(255, 255, 180);
    //Color color_not_existing = new Color(255, 150, 150);
    Color color_not_existing = new Color(230, 230, 230);


    public Component getTableCellRendererComponent
       (JTable table, Object value, boolean isSelected,
       boolean hasFocus, int row, int column) 
    {
        Component cell = super.getTableCellRendererComponent
           (table, value, isSelected, hasFocus, row, column);
        
        String  stato;
        
        cell.setBackground(Color.WHITE);
        
        s =  table.getModel().getValueAt(row, column).toString();
        if (s.equalsIgnoreCase("+")) cell.setBackground(Color.GREEN);
        if (s.equalsIgnoreCase("AL")) cell.setBackground(Color.CYAN);    
        if (s.equalsIgnoreCase(".")) cell.setBackground(color_not_existing);  
        
        if ((column == 0) | (row == 0))
        {
          cell.setBackground(Color.YELLOW);
          return(cell);
        }        
        
        
        cell.setForeground(Color.BLACK);
        return(cell);
    }
  
}