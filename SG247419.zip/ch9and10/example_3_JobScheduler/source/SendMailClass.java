import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Date;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;


public class SendMailClass implements Runnable  {
    
    String  from_address = "";
    String  to_address = "";
    String  mail_text = "";
    String  mail_subject = "";
    String  mail_server = "";
    
    //---------------------------------------
    public void set_from_address(String addr)
    {
      from_address = addr;    
    }
    
    //-------------------------------------
    public void set_to_address(String addr)
    {
      to_address = addr;    
    }
    
    //-------------------------------
    public void set_mail_text(String addr)
    {
      mail_text = addr;    
    }
    
    //---------------------------------------
    public void set_mail_server(String addr)
    {
      mail_server = addr;    
    }
    
    //---------------------------------------
    public void set_mail_subject(String addr)
    {
      mail_subject = addr;    
    }
    
    //---------------------------------------
    public void run()
    {
      try {  
      Properties props = System.getProperties();
      props.put("mail.smtp.host", mail_server);
      Session session = Session.getDefaultInstance(props, null);
      Message msg = new MimeMessage(session);
      
      msg.setFrom(new InternetAddress(from_address));
      msg.setRecipients(Message.RecipientType.TO,
        InternetAddress.parse(to_address, false));
      msg.setSubject(mail_subject);
      msg.setText(mail_text);
      msg.setSentDate(new Date());
      Transport.send(msg);
      System.out.println("message sent.");
     
      } catch (Exception ex) { 
        ex.printStackTrace();
       }
    }

    //--------------------------------------------
    public SendMailClass() {
    }
    
    
}
