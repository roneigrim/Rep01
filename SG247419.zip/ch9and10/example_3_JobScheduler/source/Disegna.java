import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;

/*
 * Disegna.java
 *
 * Created on 14 aprile 2007, 20.10
 */

/**
 *
 * @author  user1
 */
public class Disegna extends javax.swing.JFrame {
    
    Nodo  tab_nodi[] = new Nodo[100];
    int   tab_nodi_p;
    int   tab_lvl[] = new int[100];
    int   translate_x, translate_y;
    double   zoom_x, zoom_y;
    
    Graphics2D g2;
    
    Disegna_control disegna_control = new Disegna_control(this);
     
   /*--------------------*/
   public void azzera_var()
   /*--------------------*/
   { int  a;
     
     translate_x = 0;
     translate_y = 0;
     zoom_x = 1.5;
     zoom_y = 1.5;
     
     tab_nodi_p = 0;   
     
     for(a=0; a<100; a++)
     {
       tab_lvl[a] = 0;  
     }    
   }
   
   /*-----------------------------------*/
   public void set_translate(int x, int y)
   /*-----------------------------------*/
   {
     translate_x = translate_x + x;
     translate_y = translate_y + y;
     repaint();
   }
   
    /*-----------------------------------*/
   public void set_zoom(double x, double y)
   /*------------------------------------*/
   {
     zoom_x = zoom_x + x;
     zoom_y = zoom_y + y;
     repaint();
   }
   
   /*--------------------------*/
   void disegna_nodi(Graphics g2)
   /*--------------------------*/
   {
     int  a;
     Nodo n = new Nodo();
     int  x;
     int  y;
     Color  c;
     int  stato;
     long pid;
     String s;
     Font f = new Font("TimesRoman", Font.PLAIN,14);

     s = "";
     for(a=0; a<tab_nodi_p; a++)
     {
       n = tab_nodi[a];
       x = n.x;
       y = n.y;
       pid = n.pid;
       s = s.valueOf(pid);
       switch(n.stato)
       {
         case 0 : g2.setColor(Color.yellow);
                  break;
         case 1 : g2.setColor(Color.green);
                  break;         
         case 2 : g2.setColor(Color.red);
                  break;
         case 3 : g2.setColor(Color.blue);
                  break;         
         case 4 : g2.setColor(Color.cyan);
                  break;         
         default: g2.setColor(Color.gray);
                  break;
       }
       g2.fill3DRect(x-40,y-10,80,20, true);
       //g2.fillRoundRect(x-40,y-10,80,20,10,10);
       g2.setFont(f);
       g2.setColor(Color.black);
       g2.drawString(n.jobname, x-38,y+5);
     }
   }

   /*--------------------------*/
   void disegna_archi(Graphics g2)
   /*--------------------------*/
   {
     int  a,b;
     Nodo n = new Nodo();
     Nodo n1 = new Nodo();
     long ppid;
     int  x, y;
     int  x1, y1;


     for(a=0; a<tab_nodi_p; a++)
     {
       n = tab_nodi[a];
       if (n.ppid == 0) continue;
       x = n.x;
       y = n.y;
       x1 = -1;
       y1 = -1;

       for (b=0; b<tab_nodi_p; b++)
       {
         n1 = tab_nodi[b];
         if (n1.pid == n.ppid)
         {
           x1 = n1.x;
           y1 = n1.y;
           break;
         }
       }

       if (x1 < 0) continue;
       if (y1 < 0) continue;
       g2.setColor(Color.black);
       g2.drawLine(x, y, x1, y1);
     }

   }
  
    
   /*------------------------*/
   int cerca_entrata(long ppid)
   /*------------------------*/
   {
      Nodo n = new Nodo();
      int  a;

      for(a=0; a<tab_nodi_p; a++)
      {
        n = tab_nodi[a];
        if (n.pid == ppid) return(a);
      }

      return(-1);
   }
   
   /*------------------*/
   int calcola_lvl(int l)
   /*------------------*/
   {
      Nodo n = new Nodo();
      int  lvl;
      int  a;

      lvl = 0;
      for(;;)
      {
        n = tab_nodi[l];
        if (n.ppid == 0)
        {
          break;
        } else {
          ++ lvl;
          l = cerca_entrata(n.ppid);
          if (l < 0)
          {
            System.out.println("Disegna: PPid non found in the table");
            System.exit(0);
          }
        }
      }

      return(lvl);
   }

   /*------------------------*/
   void calcola_livello_grafo()
   /*------------------------*/
   {
      Nodo n = new Nodo();
      int  a;
      int  l;
      int  lvl_max;
      int  spazio_x;
      int  spazio_y;
      int  max_x;
      int  x,y;
      int  wx;

      spazio_x = 150;          /* spaziatura tra nodi allo stesso livello */
      spazio_y = 75;           /* spaziatura tra livelli */

      /* posiziono il nodo nel grafo */

      for(a=0; a<tab_nodi_p; a++)
      {
        n = tab_nodi[a];
        l = calcola_lvl(a);
        n.pos_x = tab_lvl[l];
        tab_lvl[l] = tab_lvl[l] + 1;
        n.livello = l;
        tab_nodi[a] = n;
      }

      /* calcolo il numero massimo di nodi per ogni livello */

      a = 0;
      lvl_max = 0;
      for(;;)
      {
        if (tab_lvl[a] == 0) break;
        if (tab_lvl[a] > lvl_max) lvl_max = tab_lvl[a];
        ++a;
      }

      max_x = lvl_max * spazio_x;

      for(a=0; a<tab_nodi_p; a++)
      {
        n = tab_nodi[a];
        l = tab_lvl[n.livello];
        spazio_x = max_x / (l+1);
        y = 50 + (n.livello * spazio_y);
        x = 10 + ((n.pos_x+1) * spazio_x);
        n.x = x;
        n.y = y;
        tab_nodi[a] = n;
      }
      
   }
   
   /*--------------------------------------------------------------------*/
   public void aggiungi_nodo(String jobname, long pid, long ppid, int stato)
   /*---------------------------------------------------------------------*/
   {
     Nodo n = new Nodo();

     n.pid = pid;
     n.ppid = ppid;
     n.stato = stato;
     n.jobname = jobname;
     tab_nodi[tab_nodi_p] = n;
     ++tab_nodi_p;
   }
   
 //--------------------------------------------------------------------
    public void paint(Graphics g)
    {
      int  width;
      int  height;
      
      Color back_ground = new Color(220,220,220);
      
      width = this.getWidth();
      height = this.getHeight();
      
     
      // Graphics g = jPanel1.getGraphics();
     
      g2 = (Graphics2D) g;
      g2.setColor(Color.white);   
      g2.fillRect(1, 1, width, height);        // clear the background
     // g2.setColor(Color.lightGray);
      g2.setColor(back_ground);
      g2.fill3DRect(10, 50, width-20, height-60, true);
      g2.setColor(Color.black);
      g2.drawRect(10, 50, width-20, height-60);
      g2.clipRect(10, 50, width-20, height-60);
      g2.setColor(Color.black);
      g2.translate(translate_x, translate_y);
      g2.scale(zoom_x, zoom_y);
      disegna_archi(g2);
      disegna_nodi(g2);  
      
      disegna_control.setVisible(true);
      
    }
    
    /** Creates new form Disegna */
    public Disegna() {
        initComponents();
        setLocationRelativeTo(null);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Graph display window");
        setBackground(new java.awt.Color(204, 204, 204));
        setResizable(false);
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 696, Short.MAX_VALUE)
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents
    
 
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
    
}
