/*
 * Nodo.java
 *
 * Created on 14 aprile 2007, 14.59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author user1
 */

/*------*/
public class Nodo
/*------*/
{
  long   pid;
  long   ppid;
  int    stato;
  int    livello;
  int    pos_x;
  int    x;
  int    y;
  int    max_rc;
  String jobname;
}
