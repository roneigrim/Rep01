
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.jfree.data.xy.*;
import org.jfree.data.*;

import org.jfree.chart.*;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.*;
import org.jfree.chart.axis.*;
import org.jfree.data.category.*;
import org.jfree.chart.renderer.category.*;
import org.jfree.chart.renderer.xy.*;
import org.jfree.chart.title.*;
import org.jfree.chart.block.*;
import org.jfree.ui.*;

public class submit_worker implements Runnable {
   
  Host host = new Host();
  String host_addr;
  String host_port;
  DefaultTableModel tab_job_model;
  Disegna  disegna_job;
  String  job_executing_excp_count;
  String  job_executing_cpu_time;

  Submit frame_parent;
  
  float[] tab_cpu = new float[20];
  int    tab_cpu_p;
  float[] tab_sio = new float[20];
  int    tab_sio_p;
  float[] tab_real = new float[20];
  int    tab_real_p;
  float[] tab_paging = new float[20];
  int    tab_paging_p;
    
  
  int  host_connected;
  String tab_jobnames[][] = new String[500][2];   // max 500 jobs...
  int  tab_jobnames_p = 0;
   
  SendMailClass email = new SendMailClass();
  
  //---------------------------------------------------------------------------
  public submit_worker(DefaultTableModel model, Disegna disegna, Submit frame_p)
  {
    tab_job_model = model; 
    disegna_job = disegna;
    frame_parent = frame_p;
  }
  
  //----------------------------------------------------------------------------
  private int find_jobname_number(String jobname)
  {
    int   a, i;
    
    for(a=0; a<tab_jobnames_p; a++)
    {
      if (jobname.equalsIgnoreCase(tab_jobnames[a][0])) return(100 + a);   // jobname found..
    }    
    
    return(-1);
  }
    
  //----------------------------------------------------------------------------
  private int vedi_colore_nodo(String jobname)
  {
    int    a, i;
    String colore;
    
    for(a=0; a<tab_jobnames_p; a++)
    {
      if (jobname.equalsIgnoreCase(tab_jobnames[a][0]))
      {
        i = Integer.parseInt(tab_jobnames[a][1]);
        return(i);
      }
    }    
    
    return(-1);
  }
  
  //-----------------------------------------------
  private String check_job_status(String jobname)
  {
    int    a, i;
    String stato, buf_w;
    
    stato = "";
    i = tab_job_model.getRowCount(); 
    for(a=0; a<i; a++)
    {
      buf_w = (String) tab_job_model.getValueAt(a, 0);
      if (jobname.equalsIgnoreCase(buf_w) )
      {
        stato = (String) tab_job_model.getValueAt(a, 1);   
        break;
      }
    }    
    
    return(stato);
    
  }
  
  //----------------------------------------------------------------------------
  private void plot_job_graph()
  {
    String buff, buf_w, stato;
    int  i, a, b, n, n_prec;
    int  colore_nodo;
      
    clear_jobnames_table();
    i = tab_job_model.getRowCount();  
      
    buf_w = "";
    
    for(a=0; a<i; a++)
    {
      for(b=0; b<7; b++)
      {
        if ((b==0) | (b==4) | (b==5) | (b==6))      // the jobnames are in these columns
        {    
          buf_w = (String) tab_job_model.getValueAt(a, b);
          if (buf_w.equalsIgnoreCase("none") ) continue;
          n = find_jobname_number(buf_w);         // see if this jobname already exist           
          if (n == -1)                            // no, its new. Add it to the internal table
          {
            tab_jobnames[tab_jobnames_p][0] = buf_w;
            if ((b==0) | (b==4) | (b==5) | (b==6))
            {
              stato = check_job_status(buf_w);  
              tab_jobnames[tab_jobnames_p][1] = "9";
              if (stato.equalsIgnoreCase("none") ) tab_jobnames[tab_jobnames_p][1] = "4";   // cyan
              if (stato.equalsIgnoreCase("Input Queue") ) tab_jobnames[tab_jobnames_p][1] = "0";
              if (stato.equalsIgnoreCase("Running") ) tab_jobnames[tab_jobnames_p][1] = "1";
              if (stato.equalsIgnoreCase("Ended") ) tab_jobnames[tab_jobnames_p][1] = "3";   
            }    
            ++tab_jobnames_p;
          }    
        }   
      }   
    }   
      
    // create the graph with job dependency.
      
    disegna_job.azzera_var();
   // disegna_job.set_translate(0, 20);
      
    for(a=0; a<i; a++)
    {
      for(b=0; b<7; b++)
      {
        if ((a == 0) & (b == 0))    // first job of the chain must not have dependencies..
        {
          buf_w = (String) tab_job_model.getValueAt(0, 0);  
          colore_nodo = vedi_colore_nodo(buf_w);  
          disegna_job.aggiungi_nodo( (String) tab_job_model.getValueAt(a, b), 100, 0, colore_nodo);  
        }    
        if ( (b==4) | (b==5) | (b==6) ) 
        {
          buf_w = (String) tab_job_model.getValueAt(a, 0);
          n_prec = find_jobname_number(buf_w);
          buf_w = (String) tab_job_model.getValueAt(a, b);
          if (buf_w.equals("none") ) continue;
          n = find_jobname_number(buf_w);
          colore_nodo = vedi_colore_nodo(buf_w);
          disegna_job.aggiungi_nodo(buf_w, n, n_prec, colore_nodo);
        }    
      }   
    }  
      
    disegna_job.calcola_livello_grafo();
    disegna_job.repaint();
 }
 
  //---------------------------------------------------------------------------------
  private void clear_jobnames_table()
  {
    int a;
    
    for (a=0; a<tab_jobnames_p; a++)
    {    
      tab_jobnames[a][0] = ""; 
      tab_jobnames[a][1] = ""; 
    }
    tab_jobnames_p = 0;
         
  }
    
  //--------------------------- 
  public void get_server_info()
  {
    try {
      BufferedReader in = new BufferedReader(new FileReader("example3.txt"));
      String str;
      host_addr = in.readLine();        
      host_port = in.readLine();
      in.close();
    } catch(IOException e) {
      System.out.println("Thread_1: Error reading -> example3.txt");  
      System.exit(-1);
    }  
  }
  
  //----------------------------------
  private int submit_job(String jobid)
  {
    String  s;
    
    s = "";
    s = "M" + jobid;      
    host.cmd(s);              
    s = host.get_data_from_host(); 
    if (s.equalsIgnoreCase("Submitted") ) return(1);     
    return(0);
  }
  
  //----------------------------------
  private String get_job_rc(String jobid)
  {
    String  s, jname, jid, jmaxrc;
    int  a;
    
    s = "";
    s = "X" + jobid;      
    host.cmd(s);              
    s = host.get_data_from_host();
    
    StringTokenizer st = new StringTokenizer(s);
    jname = st.nextToken();
    jid = st.nextToken();
    jmaxrc = st.nextToken();
    
    return(jmaxrc);
    
  }
  
  //-----------------------------------------------
  private void clear_graphic_tables()
  {
    int  a;
    
    for(a=0; a<20; a++)
    {
      tab_cpu[a] = 0;   
      tab_sio[a] = 0;
      tab_real[a] = 0;
      tab_paging[a] = 0;
    }    
    
    tab_cpu_p = 0;
    tab_sio_p = 0;
    tab_real_p = 0;
    tab_paging_p = 0;
    
  }
  
  //-----------------------------------------------
  private void update_graph_cpu_usage(String s)
  {
    int i, campione;
    
    XYSeries series_cpu = new XYSeries("CPU");
      
    tab_cpu[tab_cpu_p] = Float.parseFloat(s);   
    ++tab_cpu_p;
    if (tab_cpu_p == 20) tab_cpu_p = 0;
  
    i = tab_cpu_p;
    campione = 0;
         
    for(;;)                                  
    {   
      series_cpu.add(campione, tab_cpu[i]);
      ++campione;
      ++i;
      if (i == tab_cpu_p) break;
      if (i == 20) i = 0;
      if ((i ==0) & (tab_cpu_p == 0)) break;
    }
     
    XYDataset xyDataset_1 = new XYSeriesCollection(series_cpu);    
    JFreeChart chart_1 = ChartFactory.createXYAreaChart
        ("CPU usage", "Sample", "CPU %",
         xyDataset_1, PlotOrientation.VERTICAL, true, 
          true, false);
     
    XYPlot plot = (XYPlot) chart_1.getPlot();
    XYAreaRenderer renderer = (XYAreaRenderer) plot.getRenderer();
    renderer.setSeriesPaint(0, Color.green);
    
    BufferedImage image_1 = chart_1.createBufferedImage(480,200);
    frame_parent.set_label1(new ImageIcon(image_1));
  }
  
  
  //-----------------------------------------------
  private void update_graph_sio_usage(String s)
  {
    int i, campione;
    
    XYSeries series_sio = new XYSeries("SIO");
      
    tab_sio[tab_sio_p] = Float.parseFloat(s);   
    ++tab_sio_p;
    if (tab_sio_p == 20) tab_sio_p = 0;
  
    i = tab_sio_p;
    campione = 0;
     
    for(;;)                                  
    {   
      series_sio.add(campione, tab_sio[i]);
      ++campione;
      ++i;
      if (i == tab_sio_p) break;
      if (i == 20) i = 0;
      if ((i ==0) & (tab_sio_p == 0)) break;
    }
     
     XYDataset xyDataset_2 = new XYSeriesCollection(series_sio);    
     JFreeChart chart_2 = ChartFactory.createXYAreaChart
         ("SIO seconds", "Sample", "SIO Rate",
          xyDataset_2, PlotOrientation.VERTICAL, true, 
           true, false);
     
     XYPlot plot = (XYPlot) chart_2.getPlot();
     XYAreaRenderer renderer = (XYAreaRenderer) plot.getRenderer();
     renderer.setSeriesPaint(0, Color.blue);
    
     BufferedImage image_2 = chart_2.createBufferedImage(480,200);
     frame_parent.set_label2(new ImageIcon(image_2));
  }
  
 
  //-----------------------------------------------
  private void update_graph_paging_usage(String s)
  {
    int i, campione;
    
    XYSeries series_paging = new XYSeries("PAGING");
      
    tab_paging[tab_paging_p] = Float.parseFloat(s);   
    ++tab_paging_p;
    if (tab_paging_p == 20) tab_paging_p = 0;
  
    i = tab_paging_p;
    campione = 0;
     
    for(;;)                                  
    {   
      series_paging.add(campione, tab_paging[i]);
      ++campione;
      ++i;
      if (i == tab_paging_p) break;
      if (i == 20) i = 0;
      if ((i ==0) & (tab_paging_p == 0)) break;
    }
     
     XYDataset xyDataset_4 = new XYSeriesCollection(series_paging);    
     JFreeChart chart_4 = ChartFactory.createXYAreaChart
         ("Paging Activity", "Sample", "Pages%",
          xyDataset_4, PlotOrientation.VERTICAL, true, 
           true, false);
     
     XYPlot plot = (XYPlot) chart_4.getPlot();
     XYAreaRenderer renderer = (XYAreaRenderer) plot.getRenderer();
     renderer.setSeriesPaint(0, Color.yellow);
     
     BufferedImage image_4 = chart_4.createBufferedImage(480,200);
     frame_parent.set_label4(new ImageIcon(image_4));
  }
  
  //-----------------------------------------------
  private void update_graph_real_usage(String s)
  {
    int i, campione;
    
    XYSeries series_real = new XYSeries("REAL");
      
    tab_real[tab_real_p] = Float.parseFloat(s);   
    ++tab_real_p;
    if (tab_real_p == 20) tab_real_p = 0;
  
    i = tab_real_p;
    campione = 0;
     
    for(;;)                                  
    {   
      series_real.add(campione, tab_real[i]);
      ++campione;
      ++i;
      if (i == tab_real_p) break;
      if (i == 20) i = 0;
      if ((i ==0) & (tab_real_p == 0)) break;
    }
     
     XYDataset xyDataset_3 = new XYSeriesCollection(series_real);    
     JFreeChart chart_3 = ChartFactory.createXYAreaChart
         ("REAL pages in use", "Sample", "Pages",
          xyDataset_3, PlotOrientation.VERTICAL, true, 
           true, false);
     
     BufferedImage image_3 = chart_3.createBufferedImage(480,200);
     frame_parent.set_label3(new ImageIcon(image_3));
  }
 
  //-----------------------------------------------------------------------------
  private void update_runtine_values(String s, String s_1, String s_2, String s_3)
  {
    frame_parent.set_labels(s, s_1, s_2, s_3); 
  }
  
  //-----------------------------------------------
  private int check_if_job_is_running(String jobid)
  {
    String  s;
    String jname, job_id, paging, excprt, cpupr, asid, swapr, cpu, excp, real, step_n;
    
    s = "";
    s = "K" + jobid;
    host.cmd(s);              
    s = host.get_data_from_host();   
    if (s.equalsIgnoreCase("not_executing") ) return(1);     
    
    StringTokenizer st = new StringTokenizer(s);
    jname = st.nextToken();
    step_n = st.nextToken();
    job_id = st.nextToken();
    real = st.nextToken();
    paging = st.nextToken();
    excprt = st.nextToken();
    cpupr = st.nextToken();
    asid = st.nextToken();
    excp = st.nextToken();
    cpu = st.nextToken();

    update_graph_cpu_usage(cpupr);
    update_graph_sio_usage(excprt);
    update_graph_real_usage(real);
    update_graph_paging_usage(paging);
    step_n = jname + "." + step_n;
    update_runtine_values(asid, excp, cpu, step_n);
    
    job_executing_cpu_time = cpu;
    job_executing_excp_count = excp;
    
    return(0);  
  }
  
  //---------------------------------
  private void aspetta(int sec)
  {
    int  a;
    
    a = sec * 1000;
    try {
      Thread.sleep(a);
    } catch (InterruptedException e) {
      System.out.println("submit_worker: Error in thread.sleep");
      System.exit(-1); 
    }
    
  }
  
  //-------------------------------------------------------
  public int select_next_job(int job_selected, String rc_prec)
  {
    int    a, b, num;
    String s, s_w;
    
    a = 6;
    if (rc_prec.equalsIgnoreCase("0000_") ) a = 4;
    if (rc_prec.equalsIgnoreCase("0004_") ) a = 5; 
    s = (String) tab_job_model.getValueAt(job_selected, a);   // next job based on rc
    System.out.println("next job" + s);
    if (s.equalsIgnoreCase("none")) return(-1);
    
    num = tab_job_model.getRowCount();    
    for(b=0; b<num; b++)
    {
      s_w = (String) tab_job_model.getValueAt(b, 0);
      if (s_w.equalsIgnoreCase(s) ) break;
    }    
        
    return(b);
    
  }
  
  //---------------------------------------------
  private void check_if_job_to_be_cancelled(int i)
  {
    String  stato = "";
    String  jobid = "";
    String  s = "";
    
    stato = (String) tab_job_model.getValueAt(i, 7);
    if (stato.equalsIgnoreCase("Manual C"))
    {
      jobid = (String) tab_job_model.getValueAt(i, 2);   
      s = "";
      s = "L" + jobid;
      host.cmd(s);   
    } 
    
  }
  
  //---------------------------------------------------
  private void send_an_email(int tipo, String jobname)
  {
    email.mail_subject = "Jobname: " + jobname + " limit exceeded.";
    email.from_address = "example3@it.ibm.com";
    email.to_address = "dario_facchinetti@it.ibm.com";
    email.set_mail_server("emea.relay.ibm.com");
    if (tipo == 0) email.mail_text = "The job in subject hit the EXCP limit imposed.";
    if (tipo == 1) email.mail_text = "The job in subject hit the CPU limit imposed.";   
    email.run();
  }
  
  //-------------------------------------
  private void check_job_limit(int i)
  {
    String  limit, value, action, job_name;
    int     i_val, exec_val;
    float   f_val, f_exec_val;
    
    
    action = (String) tab_job_model.getValueAt(i, 7);
    limit  = (String) tab_job_model.getValueAt(i, 8);
    value  = (String) tab_job_model.getValueAt(i, 9);
    job_name = (String) tab_job_model.getValueAt(i, 0);
    
    if (limit.equalsIgnoreCase("EXCP-CNT"))                     // check the excp count
    {
      i_val = Integer.parseInt(value);
      exec_val = Integer.parseInt(job_executing_excp_count);
      if (exec_val > i_val)
      {
        if (action.equalsIgnoreCase("CANCEL")) tab_job_model.setValueAt("Manual C", i, 7);
        if (action.equalsIgnoreCase("MAIL"))  send_an_email(0, job_name);  
      }    
    }  
    
    if (limit.equalsIgnoreCase("CPU-TIME"))
    {
      f_val = Float.parseFloat(value);  
      f_exec_val = Float.parseFloat(job_executing_cpu_time);
      if (f_exec_val > f_val)
      {
        if (action.equalsIgnoreCase("CANCEL")) tab_job_model.setValueAt("Manual C", i, 7);
        if (action.equalsIgnoreCase("MAIL"))  send_an_email(1, job_name); 
      }    
    }    
  
  }
  
  //--------------------------------- 
  public void run()
  {
    String  s, rc_job_prec;;
    String  tab_jobid;
    int     a, rc, num_job, job_selected, next_job;
    
    get_server_info();
    host.connect(host_addr, host_port);
    host_connected = 1;
    
    // submit the   jobs in the group
   
    job_selected = 0;
    disegna_job.set_translate(0, 20);
    
    for(;;)
    { 
      plot_job_graph();  
      tab_jobid = (String) tab_job_model.getValueAt(job_selected, 2);
      rc = submit_job(tab_jobid);
      if (rc == 1) tab_job_model.setValueAt("Running", job_selected, 1);
      
      plot_job_graph(); 
      aspetta(1);   
      
      // we have just submitted a job.
      // We'll wait here until it teminates...
      
      clear_graphic_tables();
      
      for(;;)
      {    
        plot_job_graph();  
        rc = check_if_job_is_running(tab_jobid);
        if (rc == 1)
        {
          tab_job_model.setValueAt("Ended", job_selected, 1);
          rc_job_prec = get_job_rc(tab_jobid);                     // get rc of prev job
          tab_job_model.setValueAt(rc_job_prec, job_selected, 3);  // set rc into the table
          break;
        }     
        check_job_limit(job_selected);
        check_if_job_to_be_cancelled(job_selected);
        aspetta(5);                                                // wait for a while
      }
      
      plot_job_graph(); 
      job_selected = select_next_job(job_selected, rc_job_prec);      // select next job
      if (job_selected == -1) break; 
    }
    
    host.close();
    host_connected = 0;
    
    JOptionPane.showMessageDialog(null,
            "\n Schedule of the job is complete. " +
            "\n\n\n Press OK to continue\n\n");
  }

}
