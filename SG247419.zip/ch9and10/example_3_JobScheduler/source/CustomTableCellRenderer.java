import java.awt.Component;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class CustomTableCellRenderer extends DefaultTableCellRenderer 
{
    String s;
    Color color_selected = new Color(255, 255, 180);

    public Component getTableCellRendererComponent
       (JTable table, Object value, boolean isSelected,
       boolean hasFocus, int row, int column) 
    {
        Component cell = super.getTableCellRendererComponent
           (table, value, isSelected, hasFocus, row, column);
        
        cell.setBackground(Color.WHITE);
      
        if (isSelected)
        {
          cell.setBackground(color_selected);  
        }   
        
        if (column == 1)
        {
          cell.setBackground(Color.CYAN);                   
          s =  table.getModel().getValueAt(row, 1).toString();
          if (s.equalsIgnoreCase("Input Queue"))  
          {
             cell.setBackground( Color.YELLOW);   
          }
          if (s.equalsIgnoreCase("Running"))  
          {
             cell.setBackground( Color.GREEN);   
          }
          if (s.equalsIgnoreCase("Ended"))  
          {
             cell.setBackground( Color.BLUE);   
          }
        }        
        
        if (column == 3)
        {
          cell.setBackground(Color.RED);                   
          s =  table.getModel().getValueAt(row, 3).toString();
          if (s.equalsIgnoreCase("0000_"))  
          {
             cell.setBackground( Color.GREEN);   
          }
          if (s.equalsIgnoreCase("0004_"))  
          {
             cell.setBackground( Color.YELLOW);   
          }
          if (s.equalsIgnoreCase("none"))  
          {
             cell.setBackground( Color.WHITE);   
          }
        } 
        cell.setForeground(Color.BLACK);
        return(cell);
    }
}