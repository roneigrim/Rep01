import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;
import javax.swing.JFileChooser;
import javax.swing.table.DefaultTableModel;
/*
 * JobGroup.java
 *
 * Created on 16 aprile 2007, 17.10
 */

/**
 *
 * @author  user1
 */
public class JobGroup extends javax.swing.JFrame {
    
    DefaultTableModel model = new DefaultTableModel();
    Disegna disegna = new Disegna();
 
    String tab_jobnames[] = new String[500];   // max 500 jobs...
    int  tab_jobnames_p = 0;
      
    /** Creates new form JobGroup */
    public JobGroup() {
       initComponents();
       setLocationRelativeTo(null);
       model = (DefaultTableModel) jTable1.getModel();  
    }
    
    //-----------------------
    public void clear_table()
    {
      int  a;
      
      a = model.getRowCount();           // clear the table
       if (a > 0)
       {
         a = a - 1;
         for(;;)
         {
           if (a < 0) break;
           model.removeRow(a); 
           --a;
         }    
       }
    }
    
    //----------------------------------------------------------------------------
    private int find_jobname_number(String jobname)
    {
      int   a, i;
      
      for(a=0; a<tab_jobnames_p; a++)
      {
        if (jobname.equals(tab_jobnames[a])) return(100 + a);   // jobname found..
      }    
      
      return(-1);
    }
    
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jButton3 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setResizable(false);
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Job Name", "RC = 0", "RC = 4", "RC > 4", "Action", "Limit ", "Limit Value"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.setText("Add entry");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Delete entry");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextField1.setText("jobname");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel1.setText("JOBNAME:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel2.setText("RC0:");

        jTextField2.setText("none");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel3.setText("RC4:");

        jTextField3.setText("none");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel4.setText("RC > 4:");

        jTextField4.setText("none");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel5.setText("Value");

        jTextField5.setText("0");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NONE", "EXCP-CNT", "CPU-TIME" }));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel6.setText("LIMIT:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 13));
        jLabel7.setText("ACTION:");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NONE", "CANCEL", "MAIL" }));

        jButton3.setText("Plot Job Group");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                            .addComponent(jTextField4, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(27, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(27, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 457, Short.MAX_VALUE))
                .addContainerGap())
        );

        jMenu1.setText("File");
        jMenuItem1.setText("Load Group");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Save Group");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Exit");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

    //---------------------------------------------------------------------------------
    private void clear_jobnames_table()
    {
      int a;
      
      for (a=0; a<tab_jobnames_p; a++)
          tab_jobnames[a] = "";
     
      tab_jobnames_p = 0;
          
    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
     
      // Create an internal  table (tab_jobnames) that contains all the jobnames typed in
      // When done, every jobname has associated a number that will be used
      //  to calculate the dependecies between jobs into the graph
      // The number associated to a job is its position into the table..
      
      String buff, buf_w;
      int  i, a, b, n, n_prec;
      
      clear_jobnames_table();
      
      i = model.getRowCount();
      
      for(a=0; a<i; a++)
      {
        for(b=0; b<4; b++)
        {
          buf_w = (String) model.getValueAt(a, b);
          if (buf_w.equals("none") ) continue;
          n = find_jobname_number(buf_w);         // see if this jobname already exist           
          if (n == -1)                            // no, its new. Add it to the internal table
          {
            tab_jobnames[tab_jobnames_p] = buf_w;
            ++tab_jobnames_p;
          }   
        }   
      }   
      
      // create the graph with job dependency.
      
      disegna.setVisible(true);
      disegna.azzera_var();
      disegna.set_translate(0, 20);
      
      for(a=0; a<i; a++)
      {
        for(b=0; b<4; b++)
        {
          if ((a == 0) & (b == 0))    // first job of the chain must not have dependencies..
          {
            disegna.aggiungi_nodo( (String) model.getValueAt(a, b), 100, 0, 0);  
          }    
          if (b > 0) 
          {
            buf_w = (String) model.getValueAt(a, 0);
            n_prec = find_jobname_number(buf_w);
            buf_w = (String) model.getValueAt(a, b);
            if (buf_w.equals("none") ) continue;
            n = find_jobname_number(buf_w);
            disegna.aggiungi_nodo(buf_w, n, n_prec, 0);
          }    
        }   
      }  
      
      disegna.calcola_livello_grafo();
      disegna.repaint();
             
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
      String filename = "";
      String buff, buf_w;
      int  i = 0, a, b, n, n_prec;
        
      
      
      // We save the Jtable into a file 
      
      i = model.getRowCount();
      
      JFileChooser fc = new JFileChooser(new File(filename));
      fc.showSaveDialog(null);
      File selFile = fc.getSelectedFile();
      BufferedWriter out;
      try {
        out = new BufferedWriter(new FileWriter(selFile));
        for(a=0; a<i; a++)
        {
          buff = "";  
          for(b=0; b<7; b++)
          {
             buff = buff + (String) model.getValueAt(a, b); 
             buff = buff + " ";
             if (b == 0) 
             {
               tab_jobnames[tab_jobnames_p] = (String) model.getValueAt(a, b);
               ++tab_jobnames_p;
             }    
          }    
          out.write(buff);  
          out.newLine();
        }    
        out.close();
      } catch (IOException ex) {
        System.out.println("JobGroup: Error writing file");  
        System.exit(-1);  
      }
 
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
      String filename = "";
      String str;
      String jobname, job_0, job_4, job_m, action, limit, valore;
      int    a, i;
      
      JFileChooser fc = new JFileChooser(new File(filename));
      fc.showOpenDialog(null);
      File selFile = fc.getSelectedFile();
      
      a = model.getRowCount();           // clear the table
       if (a > 0)
       {
         a = a - 1;
         for(;;)
         {
           if (a < 0) break;
           model.removeRow(a); 
           --a;
         }    
       }
      
      try {
        BufferedReader in = new BufferedReader(new FileReader(selFile));
        for(;;)
        {    
          str = in.readLine();
          if (str == null) break;
          StringTokenizer st = new StringTokenizer(str);
          jobname = st.nextToken();
          job_0 = st.nextToken();
          job_4 = st.nextToken();
          job_m = st.nextToken();
          action = st.nextToken();
          limit = st.nextToken();
          valore = st.nextToken();
          model.addRow(new String[]{ jobname, job_0, job_4, job_m, action, limit, valore});
        }
        in.close();
      } catch(IOException e) {
        System.out.println("JobGroup: Error reading file");  
        System.exit(-1);
      }
      
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       int  i;
       
       i = jTable1.getSelectedRow();
       if (i < 0) return;
       model.removeRow(i);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      String jobname, job_0, job_4, job_m, limit, action, valore;
      int  i;
      
      jobname  = jTextField1.getText();
      job_0 = jTextField2.getText();
      job_4 = jTextField3.getText();
      job_m = jTextField4.getText();
      valore = jTextField5.getText();
      
      limit = "";
      i  = jComboBox1.getSelectedIndex();
      switch(i)
      {
          case 0 : limit = "None";
                   break;
          case 1 : limit = "EXCP-Time";
                   break;      
          case 2 : limit = "CPU-Time";
                   break;            
      }
      
      action = "";
      i  = jComboBox2.getSelectedIndex();
      switch(i)
      {
          case 0 : action = "None";
                   break;
          case 1 : action = "Cancel";
                   break;      
          case 2 : action = "Message";
                   break;      
          case 3 : action = "Mail";
                   break;          
      }
      
      model.addRow(new String[]{ jobname, job_0, job_4, job_m, action, limit, valore});
      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
      this.setVisible(false);
    }//GEN-LAST:event_jMenuItem3ActionPerformed
    
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
    
}
