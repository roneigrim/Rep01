To run the REXX exec @SYSLOG:

1. Copy it into your CLIST library
2. Copy JCL into your JCL library
3. Change SYSEXEC DD in JCL to point to your REXX exec

You will need the REXX exec @SYSCMD found in the IBM Redbooks publication, Chapter 1, Implementing REXX Support in SDSF, SG24-7419.