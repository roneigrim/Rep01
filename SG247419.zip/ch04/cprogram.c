#pragma filetag("IBM-037")
#pragma strings(readonly)
#pragma linkage(rexxsdsf,OS)
#pragma runopts(PLIST(MVS))
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <assert.h>

/*====================================================================+
 | Data areas defining the Assembler program interface area           |
 +====================================================================*/

/*--------------------------------------------------------------------+
 | R4SAREA is the anchor for the request.                             |
 +--------------------------------------------------------------------*/
typedef struct
{
    char  R4SAOPT1;
    char  R4SAOPT2;
    char  R4SAOPT3;
    char  R4SAOPT4;
    void *R4SACMD;
    void *R4SAVARS;
    void *R4SADATA;
} R4SAREA;

typedef struct
{
    short  R4SRLNG;
    char   R4SRDATA;
} R4SREFER;

typedef struct
{
    void *R4VARADR;
    char  R4VOPTS�4�;
    void *R4VARDAT;
} R4VARTYPE;

typedef struct {
    char  R4SCNAME�8�;
    int   R4SCROWS;
    void *R4SCMEMB;
} R4SCOLS;

typedef struct
{
    char     R4SDEYE�4�;
    int      R4SDLENG;
    int      R4SDCNT;
    R4SCOLS *R4SDCOLS�1�;
} R4SDATA;

typedef int (*ASMFUNC)(R4SAREA *);


/*--------------------------------------------------------------------+
 | Create one new SDSF string                                         |
 +--------------------------------------------------------------------*/
void *newr4s_string(char *name)
{
    void  *varname  = NULL;
    short varlen    = 0;

    if (name == NULL) return NULL;

    assert((varlen  = strlen(name)) != 0);
    assert((varname = malloc(sizeof(short)+varlen)) != NULL);

    memcpy(varname,&varlen,sizeof(short));
    memcpy(varname+sizeof(short),name,varlen);

    return (varname);
}


/*--------------------------------------------------------------------+
 | Create one new SDSF special variable name                          |
 +--------------------------------------------------------------------*/
void r4s_variable(R4VARTYPE *var,char *name,char options�4�,char *data)
{
    void  *varname  = NULL;
    void  *value    = NULL;

    varname = newr4s_string(name);
    value   = newr4s_string(data);
    var->R4VARADR = varname;
    var->R4VARDAT = value;
    memcpy(var->R4VOPTS,options,4);
}


void dump_column(R4SCOLS *c)
{
    char name�9�;
    char *value;
    int  rows;
    char *pdata;
    char **data;
    short length;
    int i;

    memcpy(name,c->R4SCNAME,8);
    name�8� = '\0';
    rows = c->R4SCROWS;
    fprintf(stderr,"Column = %s\n",name);
    fprintf(stderr,"Rows   = %d\n",rows);
    for (i = 1, data = (char **)&c->R4SCMEMB;i <= rows; i++)
    {
        pdata = *data;
        memcpy(&length,pdata,sizeof(short));
        fprintf(stderr,"Length = %d\n",length);
        assert((value = malloc(length+1)) != NULL);
        /*
         * We copy only to print the data in a zero terminated string
         */
        memcpy(value,pdata+sizeof(short),length);
        value�length� ='\0';
        fprintf(stderr,"Value  = %s\n",value);
        free(value);
        data++;
    }
}


/*--------------------------------------------------------------------+
 | Dump the data area                                                 |
 +--------------------------------------------------------------------*/
void dump_datarea ( R4SDATA *data )
{
    int i;
    R4SCOLS *column;

    if (memcmp(data->R4SDEYE,"R4SD",4) == 0)
    {
       fprintf(stderr,"Eyecatcher == \"R4SD\"\n");
       fprintf(stderr,"Length = %d\n",data->R4SDLENG);
       fprintf(stderr,"Count  = %d\n",data->R4SDCNT);
       for (i = 0;i < data->R4SDCNT; i++)
       {
           column = data->R4SDCOLS�i�;
           dump_column(column);
       }
    }
}


int main( int argc, char **argv )
{
    ASMFUNC rexxsdsf;
    R4SAREA r4sarea;

    struct {
      short length;
      char  output�UCHAR_MAX�;
    } msg_area;
    struct {
      int   nvars;
      R4VARTYPE prefix;
      R4VARTYPE owner;
      R4VARTYPE cols;
      R4VARTYPE msg;
    } vars;
    int rc = 0;
    register int i;

    /*----------------------------------------------------------------*/
    /* Dump the parameters received                                   */
    /*----------------------------------------------------------------*/
    for (i = 0; i < argc; i++)
        fprintf(stderr,"%s parameter %d\t%s\n",__func__,i,argv�i�);

    /*----------------------------------------------------------------*/
    /* Let's initialize the anchor area for the request               */
    /*----------------------------------------------------------------*/
    vars.nvars  = 4;
    r4s_variable(&vars.prefix,"ISFPREFIX","S   ",argv�1�);
    r4s_variable(&vars.owner, "ISFOWNER" ,"S   ","*" );
    r4s_variable(&vars.cols, "ISFCOLS" ,"S   ","JNAME JOBID RETCODE");
    r4s_variable(&vars.msg, "ISFMSG"   ,"R   ",(void *)&msg_area );
    memset(msg_area.output,0,UCHAR_MAX);
    msg_area.length = UCHAR_MAX;

    r4sarea.R4SAOPT1 = 'Y';
    r4sarea.R4SAVARS = &vars;
    r4sarea.R4SACMD  = newr4s_string("ISFEXEC ST");
    r4sarea.R4SADATA = NULL;

    if ( (rexxsdsf = (ASMFUNC) fetch("REXXSDSF")) == NULL )
       fprintf(stderr,"%s: Error loading routine REXXSDSF\n",__func__);
    else
    {
       fprintf(stderr,"%s: REXXSDSF routine loaded\n",__func__);
       rc = rexxsdsf(&r4sarea);
       if (rc != 0)
          fprintf(stderr,"Error executing REXXSDSF, rc=%d\n",rc);
       else
       {
          fprintf(stderr,"REXXSDSF returned with a rc = 0\n");
          dump_datarea((R4SDATA *)r4sarea.R4SADATA);
       }
    }

    release((void(*)())rexxsdsf);

    exit(123);
}
