To run the code provided in the IBM Redbooks publication,  Chapter 8, Implementing REXX support in SDSF, SG24-7419.

1. You must have or create a panels library, a ISPTBL library and a DTL library

2. Upload REXX exec (extension .rex) to your REXX library

3. Upload JCL (server job) to your JCL library

4. Change the SYSEXEC dd to point to your REXX execs library

5. Modify the port number to one that is available in your installation

6. Upload panels (extension .pnl) as BINARY DATA to your panel library

7. Upload dtl (extension .dtl) to a dtl library

8. Compile cmdtbl.dtl using ISPDTLC

9. Sumbit the server job

10. Execute the REXX @ISPCL and pass as a parameter, the prefix of your libraries(see the following example. Replace 'ITSOUSR.test'with your library name). This exec will run ALTLIB for you.
    
   tso ex 'ITSOUSR.TEST.REXX(@ISPCL)' 'ITSOUSR.TEST'