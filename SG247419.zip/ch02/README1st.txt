Instructions for installing and using BUILDPDS, the REXX EXEC which copies SYSOUT to a PDS.

For details on what this EXEC does and how it does it, see the IBM Redbooks publication, chapter 3, Implementing REXX Support in SDSF, SG24-7419

To install, simply copy the BUILDPDS.REX file to a CLIST dataset and execute it using the parameters described in the manual.
To run in batch, use the BUILDPDS.JCL file as a template to create your own JCL.

